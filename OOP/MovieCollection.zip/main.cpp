#include <iostream>
#include"movie_collection.h"
using namespace std;

int main(){

    Movie_Collection myManager;
    myManager.add_item(Movie("Dr. Strange", "Marvel", 2017));
    myManager.add_item(Movie("Dr. Strange - Multiverse of Madness", "Marvel", 2022));
    myManager.add_item(Movie("The Amazing Spiderman", "Marvel", 2014));
    myManager.add_item(Movie("Spiderman - Far from home ","Marvel", 2020));
    myManager.add_item(Movie("Spiderman - No way home ","Marvel", 2022));
    myManager.add_item(Movie("Spiderman 3", "Marvel", 2016));
    myManager.add_item(Movie("Superman", "DC", 2006));
    myManager.add_item(Movie("Pirates of Carribean", "Disney", 2011));
    myManager.add_item(Movie("Justice League", "DC", 2022));
    myManager.add_item(Movie("X-Men : Origins", "Marvel", 2014));

    cout << "Creating an object of Movie_Collection :" << endl;
    cout << myManager ;

    cout << "---------------------------------------------------------------" << endl;
    cout << "Printing indexes of movies and movie objects in a specific year by search_by_year() function :" << endl;
    int *result = myManager.search_by_year(2022);
    for (int i = 1; i < result[0]; i++) // size of array was stored in 0 index
    {
        cout << i << " , " << myManager.getMovie(result[i]) << endl;
    }

    cout << "---------------------------------------------------------------" << endl;
    cout << "Printing indexes of a movies and movie objects by search_by_name() function :" << endl;
    int *index = myManager.search_by_name("Spiderman");
    for (int i = 1; i < index[0]; i++) // size of array was stored in 0 index
    {
        cout << i << " , " << myManager.getMovie(index[i]) << endl;
    }

    cout << "---------------------------------------------------------------" << endl;
    cout << "Deleting movies by name :" << endl << "All spiderman movies are deleted.." <<endl;
    myManager.delete_item("Spiderman");
    cout << myManager;
    cout << "---------------------------------------------------------------" << endl;
    cout << "Deleting movies by year :" << endl << "All 2022 movies are deleted.." <<endl;
    myManager.delete_item(2022);
    cout << myManager;

    return 0;
}