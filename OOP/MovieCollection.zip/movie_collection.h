#include <iostream>
#include <regex>
#include <algorithm>
#include "movie.h"
using namespace std;

class Movie_Collection{
    private:
        Movie *m;
        int maxcapacity;
        int count;
        
        void increase_size()
        {
            Movie *mm = new Movie[maxcapacity * 2];
            copy(m, m + maxcapacity, mm);
            maxcapacity *= 2;
            delete[] m;
            m = mm;
        }

    public:
        Movie_Collection()
        {
            maxcapacity = 10;
            m = new Movie[maxcapacity];
            count = 0;
        }

        void setMaxcapacity(int maincapacity)
        {
            this->maxcapacity = maincapacity;
        }

        void setCount(int count)
        {
            this->count = count;
        }

        int getMaxcapacity()
        {
            return maxcapacity;
        }
        
        int getCount()
        {
            return count;
        }
        Movie getMovie(int index)
        {
            return m[index];
        }
        void decrease_size()
        {
            Movie *mm = new Movie[count];
            copy(m, m + count, mm);
            delete[] m;
            m = mm;
        }

        void add_item(Movie  mo)
        {
            if(count == maxcapacity)
            {
                increase_size();
            }
            m[count] = mo;
            count++;
        }

        void delete_item(string movie_name)
        {   
            int* p = search_by_name(movie_name);
            Movie *mm = new Movie[count];
           int b = 0;
           for(int i = 0; i < count; i++)
           {    
                auto found = find(p + 1, p + p[0], i);
                if (found == p + p[0]){
                    mm[b] = m[i];
                    b++;
                }
           }
           count = count - p[0] + 1;
           delete[] m;
           m = mm;
        }

        void delete_item(int year)
        {   
            int* p = search_by_year(year);
            Movie* mm = new Movie[count];
           int b = 0;
           for(int i = 0; i < count; i++)
           {    
                auto found = find(p + 1, p + p[0], i);
                if (found == p +p[0]){
                    mm[b] = m[i];
                    b++;
                }
           }
           count = count - p[0] + 1;
           delete[] m;
           m = mm;
        }

        int* search_by_year(int x)
        {
            int *year = new int[count];
            int a = 1;
            for(int i =0; i < count; i++)
            {
                if(m[i].getYear() == x)
                {
                    year[a] = i;
                    a++;
                }
            } 
            // Storing the size of array in 0 index as meta-data
            year[0] = a ;
            return year;
        }

        int* search_by_name(string name_movie)
        {
            int *name = new int[count];
            int b = 1;
            regex pattern(".*" + name_movie + ".*", regex_constants::icase);
            for(int i = 0; i < count; i++)
            {
                if(regex_match(m[i].getMovie_name(), pattern))
                {
                    name[b] = i;
                    b++;
                }
            }
            // Storing the size of array in 0 index as meta-data
            name[0] = b ;
            return name;
        }

        void Edit(int index, Movie mo)
        {
            m[index] = mo;
        }

        friend ostream& operator <<(ostream &out, Movie_Collection collection){
            for (int i = 0; i < collection.count; i++){
                out << i+1 << ")" << collection.m[i] << endl;
            }

            return out;
        };
};